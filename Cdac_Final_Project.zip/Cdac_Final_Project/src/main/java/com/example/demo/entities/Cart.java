package com.example.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Lob;

import javax.persistence.Table;



@Entity
@Table(name = "cart")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartid;
	
	@Column
	private String productname;
	
	@Column
	private int productquantity;
	
	@Column
	private float productprices;
	
	@Column
	private String customeremail;
	
	@Column
	private float totalprices;
	
	@Lob
	private byte[] productimage;
	@Column(name = "product_id")
	private int productId;
	
	public Cart() {
		super();
	}

	public Cart(int cartid, String productname, int productquantity, float productprices, String customeremail,
			byte[] productimage ,int productId ,float totalprices) {
		super();
		this.cartid = cartid;
		this.productname = productname;
		this.productquantity = productquantity;
		this.productprices = productprices;
		this.customeremail = customeremail;
		this.productimage = productimage;
		this.productId = productId;
		this.totalprices = totalprices;
	}

	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductquantity() {
		return productquantity;
	}

	public void setProductquantity(int productquantity) {
		this.productquantity = productquantity;
	}

	public float getProductprices() {
		return productprices;
	}

	public void setProductprices(float productprices) {
		this.productprices = productprices;
	}

	public String getCustomeremail() {
		return customeremail;
	}

	public void setCustomeremail(String customeremail) {
		this.customeremail = customeremail;
	}

	public byte[] getProductimage() {
		return productimage;
	}

	public void setProductimage(byte[] productimage) {
		this.productimage = productimage;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public float getTotalprices() {
		return totalprices;
	}

	public void setTotalprices(float totalprices) {
		this.totalprices = totalprices;
	}
	
	
	
	
}
