package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constants.CartCustomException;
import com.example.demo.constants.ResponseCode;
import com.example.demo.entities.Cart;
import com.example.demo.entities.Product;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.response.ServerResponse;





@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class CartController {

	private static final boolean Cart = false;

	@Autowired
	CartRepository cRespo;
	
	@Autowired
	ProductRepository prepo;
	
	@GetMapping("/cart")
	public String cart() {
		
		return "ADD Cart";
	}
	
	@PostMapping("/addCart")
	public Cart addCart(@RequestBody Cart cart) {
		
		int cartids=cart.getProductId();
		String un=cart.getCustomeremail();
		int cardj = 0;
		int pp = 0;
		String unid =null;
		List<Cart> check=cRespo.findAll();
		
		for(Cart c : check) {	
			if(c.getProductId()==cartids) {
				int cartids1=c.getCartid();
				cardj=cartids1;
				int productId=c.getProductId();
				pp =productId;
				
				 unid=c.getCustomeremail();
			}
			
		}
		
		
		int cart_id=cardj;
		int product_id=pp;
		String u =unid;
		if(product_id == cartids && u.equals(un)) {
			Product cartItem = prepo.getById(product_id);
			
			Cart ct =cRespo.getById(cart_id);
			Cart buf = new Cart();
			buf.setCartid(ct.getCartid());
			buf.setProductname(cartItem.getPname());
			buf.setProductprices(cartItem.getPprice());
			
			int prevqty=ct.getProductquantity();
			int newqty= 1;
			int quantity= prevqty + newqty ;
			buf.setProductquantity(quantity);
			
			
			float previous =ct.getProductprices() ;
			float newprices = previous * quantity;
			buf.setTotalprices(newprices);
			buf.setProductimage(cartItem.getProductimage());
			buf.setCustomeremail(cart.getCustomeremail());
			buf.setProductId(cartItem.getPid());
		

		return this.cRespo.save(buf);
		
		}else {
			Product cartItem = prepo.getById(cart.getProductId());
			Cart buf = new Cart();
			buf.setProductname(cartItem.getPname());
			buf.setProductprices(cartItem.getPprice());
			buf.setProductquantity(1);
			buf.setTotalprices(cartItem.getPprice());
			buf.setProductimage(cartItem.getProductimage());
			buf.setCustomeremail(cart.getCustomeremail());
			buf.setProductId(cartItem.getPid());
			


			return this.cRespo.save(buf);
			
		}
	
		
	}
	
	@GetMapping("/getAllCart")
	public List<Cart> getAllCart(){
		
		return this.cRespo.findAll();
	}
	
}
