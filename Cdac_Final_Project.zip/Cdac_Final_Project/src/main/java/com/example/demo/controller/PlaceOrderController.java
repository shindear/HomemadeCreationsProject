package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Admin;
import com.example.demo.entities.Cart;
import com.example.demo.entities.Customer;
import com.example.demo.entities.OrderDetails;
import com.example.demo.entities.PlaceOrder;
import com.example.demo.entities.Product;
import com.example.demo.entities.Vendor;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.OrderDetailsRepository;
import com.example.demo.repository.PlaceOrderRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.VendorRepository;
import com.example.demo.services.ProductService;
import com.example.demo.services.SendMail;



@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class PlaceOrderController {

	
	@Autowired
	ProductRepository prepo;
	
	@Autowired
	CustomerRepository cRepos;


	@Autowired
	VendorRepository vrepo;
	
	@Autowired
	AdminRepository  aRepos;
	
	@Autowired
	CartRepository cRepose;
	
	@Autowired
	OrderDetailsRepository oRepos;
	
	@Autowired
	PlaceOrderRepository plRespos;
	
	@Autowired
	VendorRepository vRepose;
	
	@GetMapping("/place")
	public String place() {
		
		return "place Order";
	}
	
	
	@PostMapping("/placeOrder")
	public PlaceOrder placeOrder(@RequestBody PlaceOrder placeOrder) {
		
		String n=placeOrder.getCustid();
		System.out.println("custid"+n);
		
		Customer cust=cRepos.getById(Integer.parseInt(n));
		
		System.out.println("Customer"+cust.getUemail());
		
		
		String custemail=cust.getUemail();
		
		List<Cart> car=cRepose.findAll();
		float totalprices =0;
		float admintotal =0;
		float vendortotal =0;
		
		for(Cart cd : car) {
			if(cd.getCustomeremail().equals(custemail)) {
				
				 float ss =cd.getTotalprices(); 
                 
                 totalprices = totalprices + ss;
				
			}
			
		}
		System.out.println("totalprices"+totalprices);
		
		admintotal = (totalprices * 1) / 100 ;
		Admin ad=aRepos.getById(121);
		
		ad.getAdminid();
		float previoustotal=ad.getAwallet() + admintotal;
		
		
		Admin a=new Admin();
		a.setAdminid(ad.getAdminid());
		a.setApassword(ad.getApassword());
		a.setAwallet(previoustotal);
		aRepos.save(a);
		System.out.println("admintotal   "+previoustotal);
		
	
		List<Cart> cartarray=cRepose.findAll();
		 List<OrderDetails> CList = new ArrayList<OrderDetails>();
		 
		 for(Cart allOrder :cartarray) {
			 if(allOrder.getCustomeremail().equals(custemail)) {
				 
				 String produ_name = allOrder.getProductname();
				 float produ_prices = allOrder.getProductprices();
                 int produ_quantity = allOrder.getProductquantity();
                 float produ_total = allOrder.getTotalprices();
                 String productimage = allOrder.getProductname();
                 OrderDetails o =new OrderDetails();
                 o.setProdu_name(produ_name);
                 o.setProdu_prices(produ_prices);
                 o.setProdu_quantity(produ_quantity);
                 o.setProdu_total(produ_total);
                 o.setProductimage(productimage.getBytes());
                 
                 oRepos.save(o);
				 
                 CList.add(o);
				 
			 }
			 
		 }
		 


			String cname=cust.getUfname();
			String address=cust.getUaddress();
			String contact=cust.getUcontactno();
			
		  Date date = new Date();
	      SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	      String strDate = formatter.format(date);
			
			
		 placeOrder.setCname(cname);
		 placeOrder.setCustemail(custemail);
		 placeOrder.setAddress(address);
		 placeOrder.setContactno(contact);
		 placeOrder.setOrderdate(strDate);
		 placeOrder.setTotalprice(totalprices);
		 placeOrder.setOrderdetails(CList);
		 
		 int vproduid=0;
		 
		 List<Cart> ventotal=cRepose.findAll();
         for(Cart v : ventotal) {
        	 
        	 if(v.getCustomeremail().equals(custemail)) {
        		 
        		 
        		 
        		
        		 
        		 vproduid = v.getProductId();
        		
        		 
        	 }
        	 
         }
		 
         Product p=prepo.getById(vproduid);
		 vendortotal =totalprices - admintotal ; 
		 
		
		 
		 Vendor venwallet= new Vendor();
		 venwallet.setVid(p.getVdr().getVid());
		 venwallet.setVaddress(p.getVdr().getVaddress());
		 venwallet.setUniqueid(p.getVdr().getUniqueid());
		 venwallet.setVcontactno(p.getVdr().getVcontactno());
		 venwallet.setVemail(p.getVdr().getVemail());
		 venwallet.setVfname(p.getVdr().getVfname());
		 venwallet.setVlname(p.getVdr().getVlname());
		 venwallet.setVpassword(p.getVdr().getVpassword());
		 venwallet.setVstatus(p.getVdr().getVstatus());
		 
		 float prviouswallet=p.getVdr().getVwallet() +vendortotal ;
		 
		 venwallet.setVwallet(prviouswallet);
		 
		 vRepose.save(venwallet);
         
         
		 
             List<Cart> deletcart=cRepose.findAll();
             for(Cart d : deletcart) {
            	 
            	 if(d.getCustomeremail().equals(custemail)) {
            		 
            		 Cart del=new Cart();
            		 
            		 del.setCartid(d.getCartid());
            		 
            		 cRepose.delete(del);
            	 }
            	 
             }
		 
             String email=custemail;
             String subject="Congratulation Your Order has begin Placed";
             String msg = "Welcome to Home Made Creation" + "\n\n" + "Dear " +   cust.getUfname()   + ",You have successfully Placed Order. Order will be delivered at "+   cust.getUaddress()   + "  is your Home Address" ;
              SendMail.mailsend(email,msg, subject);
             
		return this.plRespos.save(placeOrder);
	}
	
	
	@GetMapping("/getPlaceOrder")
	public List<PlaceOrder> getAllPlaceOrder(){
		
		return this.plRespos.findAll();
	}
}
