package com.example.demo.response;

import java.util.List;

import com.example.demo.entities.Product;



public class ProductResponse {
	private String status;
	private String message;
	
	private List<Product> oblist;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Product> getOblist() {
		return oblist;
	}

	public void setOblist(List<Product> oblist) {
		this.oblist = oblist;
	}
	
	
	
}
