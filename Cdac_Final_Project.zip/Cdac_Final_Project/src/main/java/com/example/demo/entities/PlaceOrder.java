package com.example.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "placeOrder")
public class PlaceOrder {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderid;
	
	@Column
	private String cname;
	@Column
	private String address;
	
	@Column
	private String custemail;
	
	@Column
	private String contactno;
	@Column
	private float totalprice;
	@Column
	private String orderdate;
	
	@Column
	private String status="Placed";
	
	@Column
	private String custid;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
    private List<OrderDetails> orderdetails;
	
	
	public PlaceOrder() {
		super();
		
	}


	public PlaceOrder(int orderid, String cname, String address, String contactno, float totalprice, String orderdate,
			String status, List<OrderDetails> orderdetails,String custid,String custemail) {
		super();
		this.orderid = orderid;
		this.cname = cname;
		this.address = address;
		this.contactno = contactno;
		this.totalprice = totalprice;
		this.orderdate = orderdate;
		this.status = status;
		this.orderdetails = orderdetails;
		this.custid = custid;
		this.custemail = custemail;
	}


	public int getOrderid() {
		return orderid;
	}


	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}


	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getContactno() {
		return contactno;
	}


	public void setContactno(String contactno) {
		this.contactno = contactno;
	}


	public float getTotalprice() {
		return totalprice;
	}


	public void setTotalprice(float totalprice) {
		this.totalprice = totalprice;
	}


	public String getOrderdate() {
		return orderdate;
	}


	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public List<OrderDetails> getOrderdetails() {
		return orderdetails;
	}


	public void setOrderdetails(List<OrderDetails> orderdetails) {
		this.orderdetails = orderdetails;
	}


	public String getCustid() {
		return custid;
	}


	public void setCustid(String custid) {
		this.custid = custid;
	}


	public String getCustemail() {
		return custemail;
	}


	public void setCustemail(String custemail) {
		this.custemail = custemail;
	}
	
	
	
	
}
