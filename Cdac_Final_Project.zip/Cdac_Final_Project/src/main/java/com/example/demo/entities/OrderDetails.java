package com.example.demo.entities;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;


@Entity
public class OrderDetails {
	 @Id
	    @GeneratedValue
	    private long orderdetails_id;
	    private String produ_name;
	    private int produ_quantity;
	    private float produ_prices;
	    private float produ_total;
	    
	    @Lob
		private byte[] productimage;

	    
	    public OrderDetails() {
	    	super();
	    }



		public OrderDetails(long orderdetails_id, String produ_name, int produ_quantity, float produ_prices,
				float produ_total, byte[] productimage) {
			super();
			this.orderdetails_id = orderdetails_id;
			this.produ_name = produ_name;
			this.produ_quantity = produ_quantity;
			this.produ_prices = produ_prices;
			this.produ_total = produ_total;
			this.productimage = productimage;
		}



		public long getOrderdetails_id() {
			return orderdetails_id;
		}



		public void setOrderdetails_id(long orderdetails_id) {
			this.orderdetails_id = orderdetails_id;
		}



		public String getProdu_name() {
			return produ_name;
		}



		public void setProdu_name(String produ_name) {
			this.produ_name = produ_name;
		}



		public int getProdu_quantity() {
			return produ_quantity;
		}



		public void setProdu_quantity(int produ_quantity) {
			this.produ_quantity = produ_quantity;
		}



		public float getProdu_prices() {
			return produ_prices;
		}



		public void setProdu_prices(float produ_prices) {
			this.produ_prices = produ_prices;
		}



		public float getProdu_total() {
			return produ_total;
		}



		public void setProdu_total(float produ_total) {
			this.produ_total = produ_total;
		}



		public byte[] getProductimage() {
			return productimage;
		}



		public void setProductimage(byte[] productimage) {
			this.productimage = productimage;
		}


	    
}
