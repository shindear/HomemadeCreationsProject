package com.example.demo.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.constants.ResponseCode;
import com.example.demo.entities.Category;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductAudit;
import com.example.demo.entities.Vendor;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.VendorRepository;
import com.example.demo.response.ProductResponse;
import com.example.demo.services.ProductService;
import com.example.demo.util.Validator;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class ProductController {
	@Autowired
	ProductRepository prepo;
	
	@Autowired
	ProductService pservice;
	
	@Autowired
	CategoryRepository crepo;
	
	@Autowired
	VendorRepository vrepo;
	@GetMapping("/getallproducts")
	public List<Product> getAllProducts() {
		return pservice.getAllProducts();
		
	}
	@GetMapping("/getallproductaudit")
	public List<ProductAudit> getAllProductAudit() {
		return pservice.getAllProductAudit();
	}
//	@PostMapping("/addproduct")
//	public Product save(@RequestBody Product p) {
//		return pservice.save(p);
//	}
//*******************************************************************************************
	
	@PostMapping("/addProduct")
	public ResponseEntity<ProductResponse> addProduct(
			@RequestParam(name = "file", required = false) MultipartFile prodImage,
			@RequestParam(name = "pdesc",required = false) String pdesc,
			@RequestParam(name = "pname",required = false) String  pname,
			@RequestParam(name = "prating",required = false) String  prating,
			@RequestParam(name = "pqty",required = false) String  pqty,
			@RequestParam(name = "pprice",required = false) String  pprice,
			@RequestParam(name = "papprove",required = false) String papprove,
			@RequestParam(name = "cat",required = false) String cat,
			@RequestParam(name = "vdr",required = false) String vdr
			) throws IOException {
		ProductResponse resp = new ProductResponse();
		if (Validator.isStringEmpty(pname) || Validator.isStringEmpty(pdesc)
				|| Validator.isStringEmpty(pqty)
				) {
			resp.setStatus(ResponseCode.BAD_REQUEST_CODE);
			resp.setMessage(ResponseCode.BAD_REQUEST_MESSAGE);
			return new ResponseEntity<ProductResponse>(resp, HttpStatus.NOT_ACCEPTABLE);
		} else {
			try {
				Product prod = new Product();
				prod.setPname(pname);
				prod.setPdesc(pdesc);
				prod.setPrating(1);
				prod.setPqty(Integer.parseInt(pqty));
				prod.setPprice(Float.parseFloat(pprice));
				prod.setPapprove("true");
				
				
				Category c =crepo.getById(Integer.parseInt(cat));
				prod.setCat(c);
				
				Vendor v =vrepo.getById(Integer.parseInt(vdr));
				prod.setVdr(v);

                 System.out.println("Images "+prodImage.getBytes());
				if (prodImage != null) {
					prod.setProductimage(prodImage.getBytes());
				}
				prepo.save(prod);
//				
				resp.setStatus(ResponseCode.SUCCESS_CODE);
				resp.setMessage(ResponseCode.ADD_SUCCESS_MESSAGE);
				resp.setOblist(prepo.findAll());
			} catch (Exception e) {
				
				throw new RuntimeException("Unable to save product details, please try again");
			}
		}
		return new ResponseEntity<ProductResponse>(resp, HttpStatus.OK);
	}
	
//********************************************************************************************
	@GetMapping("/getbyid")
	public List<Product> getByCategoryId(@RequestParam("cid") int cid) {
		return pservice.getByCategoryId(cid);
	}
	@PostMapping("/searchbykeyword")
	public List<Product> searchbykeyword(@RequestBody Product p) {
		return pservice.searchbykeyword(p.getPname(), p.getPdesc());
	}
	@GetMapping("/food")
	public List<Product> getAllFood() {
		return pservice.getAllFood();
	}
	@GetMapping("/homedecor")
	public List<Product> getAllHomedecor() {
		return pservice.getAllHomedecor();
	}
	
	@GetMapping("/jewellary")
	public List<Product> getAllJewellaryAndAccessories() {
		return pservice.getAllJewellaryAndAccessories();
	}
	@GetMapping("/cloths")
	public List<Product> getAllCloths() {
		return pservice.getAllCloths();
	}
	@GetMapping("/viewbyvid")
	public List<Product> getByVid(@RequestParam("vid")int vid){
		return pservice.getByVid(vid);
	}
	@GetMapping("/productstatusaction")
	public void productStatusAction(@RequestParam("pid") int pid,@RequestParam("pprice") float pprice,@RequestParam("pqty") int pqty,@RequestParam("action") String action)
	{
		pservice.productStatusAction(pid,pprice,pqty,action);
	}
	@GetMapping("/vaddproduct")
	public void vaddproduct(@RequestParam("cname") String cname,@RequestParam("ctype")String ctype, @RequestParam("vid") int vid,
			@RequestParam("pname") String pname, @RequestParam("pdesc") String pdesc,
			
			@RequestParam("pprice") float pprice, @RequestParam("pqty") int pqty) {
		int cid = pservice.cidReturn(cname, ctype);
		pservice.vaddproduct(cid, vid, pname, pdesc, pprice, pqty);
	}
	@GetMapping("/viewoutofstock")
	public List<Product> viewOutOfStock(@RequestParam("vid") int vid)
	{
		return pservice.viewOutOfStock(vid);
	}
}
