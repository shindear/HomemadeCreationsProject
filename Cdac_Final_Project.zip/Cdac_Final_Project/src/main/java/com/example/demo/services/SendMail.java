/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.example.demo.services;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 *
 * @author accede
 */
public class SendMail {
      public static void mailsend(String email,String msg,String subject){

String to = email;
String message1=msg;
String Subject=subject;
String name=message1;

String from = "ranjitshete999@gmail.com";
final String username = "ranjitshete999@gmail.com";//change accordingly
final String password = "Ranjit@12";//change 

String host =  "smtp.gmail.com";
// Get system properties
Properties properties = new Properties();
properties.put("mail.smtp.auth", "true");
properties.put("mail.smtp.starttls.enable", "true");
properties.put("mail.smtp.host", host);
properties.put("mail.smtp.port", "587");

properties.setProperty("mail.smtp.host", host);
properties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
      
      Session session = Session.getInstance(properties,
      new javax.mail.Authenticator() {
         @Override
         protected PasswordAuthentication getPasswordAuthentication() {
         return new PasswordAuthentication(username, password);
         }
      });

      try{
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // Set To: header field of the header.
         message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));

         // Set Subject: header field
         message.setSubject(subject);

         // Send the actual HTML message, as big as you like
        
         // Send message
         
       MimeBodyPart messageBodyPart = new MimeBodyPart();

      Multipart multipart = new MimeMultipart();

       messageBodyPart = new MimeBodyPart();

        messageBodyPart.setText(msg);
        multipart.addBodyPart(messageBodyPart);

        message.setContent(multipart);

        System.out.println("Sending");
         Transport.send(message);
         System.out.println("Sent message successfully....");
      }catch (MessagingException mex) {
         mex.printStackTrace();
      }
}
    public static void main(String[] args) {
    
    }
}
