import React from 'react'
import '../Home.css';

// import baner from '../BGIMG.jpeg';
import Photo2 from '../Photo2.jpg';
import Product from './Product.js';
import CarouselComponent from '../components/CarouselComponent';
export default class Home extends React.Component{
    constructor(props)
    {
        super(props);
        this.state = {
            to: []
        }
    }
    componentDidMount =()=>{
        fetch("http://localhost:8080/getallproducts")
        .then(resp => resp.json())
        .then(data => this.setState({to: data}));
        
        //alert(this.state.to);

    }
    render(){
    return (
        // <div className='home'  style={{backgroundColor:"chocolate"}}>
        //    <div className='home_container'>
        //        {/* <img className='home_img' src={baner} alt="baner"/> */}
        //          {/* <img className='home_img' src={'./BGIMG.jpeg'} /> */}
        //        {/* <img src='BGIMG.jpeg'/> */}
        //        <img src='img2.jpeg'  style={{height:"640px"}}></img>
        // </div>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" height="450px" src='img2.jpeg' alt="First slide"/>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" height="450px" src={Photo2} alt="Second slide"/>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" height="450px" src='img2.jpeg' alt="Third slide"/>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
         
         
        
     

         

       
    )
}
}

