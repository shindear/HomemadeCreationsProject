import React ,{useState} from 'react';
import '../Footer.css';
import InstagramIcon from '@mui/icons-material/Instagram';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';

function Footer() {
   
    return (
        
        <div className='footer'>
            
            <div>
            <div className='footer_contact'>
                <h5>Contact us</h5>     </div>
                <span className='footer_helpLine'>Email: Homemade@gmail.com  Telephone: 02143-226540</span>
            </div >
            <div className='Social'>
                <h5>Follow us on:</h5>
                <div className='footer_logo'> <FacebookIcon/>
                    <InstagramIcon/>
                    <TwitterIcon/>
                    <WhatsAppIcon/>
                    </div>
            </div>
        </div>
    )
}

export default Footer
