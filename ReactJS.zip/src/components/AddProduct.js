import React from 'react';
import '../register.css';
import { Link } from 'react-router-dom';
import 'react-dropdown/style.css';
import axios from 'axios';
export default class AddProduct extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cid: "",
            file: "",
            title: "",
            describe: "",
           
            qty: "",
            price: "",
            rating: "",
            cat: [],
            selectedOption:"",
            selectedOption1:"",
            error: {

                titleerr: "",
                describeerr: "",
               
                qtyerr: "",
                priceerr: "",
                ratingerr: ""
            }
        }
        this.handleOption = this.handleOption.bind(this);
        this.handleOption1 = this.handleOption1.bind(this);
        

    }

    onChangeHandler=event=>{
        this.setState({
          file: event.target.files[0],
          loaded: 0,
        })
    }

    handleChange = (a) => {
        console.log("target", a);
        const input = a.target;
        const nm = input.name;
        let val;
        let error = this.state.error;
        
        if (nm === "title") {
            val = input.value;
            if (val.length < 5) {
                error.titleerr = "Too short Title";
            }
            else {
                error.titleerr = "";
            }
        }
        else {
            if (nm === "describe") {
                val = input.value;
                if (val.length < 10 && val.length > 100) {
                    error.describeerr = "Description should be in between 10 to 100 Characters";
                }
                else {
                    error.describeerr = "";
                }
            }
            else {
                if (nm === "size") {
                    val = input.value;
                    if (val.length > 5) {
                        error.sizeerr = "Too Large Size";
                    }
                    else {
                        error.sizeerr = "";
                    }
                }
                else {
                    if (nm === "brand") {
                        val = input.value;
                        if (val.length < 2) {
                            error.branderr = "BrandName Too Small";
                        }
                        else {
                            error.branderr = "";
                        }
                    }
                    else {
                        if (nm === "qty") {
                            val = input.value;
                                if (val.length < 1) {
                                    error.qtyerr = "Invalid Quantity";
                                }
                                else {
                                    error.qtyerr = "";
                                }

                        }
                        else {
                            if (nm === "price") {
                                val = input.value;
                                if (val.length < 1) {
                                    error.priceerr = "Invalid price";
                                }
                                else {
                                    error.priceerr = "";
                                }
                            }
                            else {
                                if (nm === "rating") {
                                    val = input.value;
                                    if (val > 5) {
                                        error.ratingerr = "Rating should not exceed 5";
                                    }
                                    else {
                                        error.ratingerr = "";
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }
        this.setState({ error, [nm]: val })

    }

   /* handleOption= selectedOption => {
        this.setState({ selectedOption });
        console.log('Option selected:',selectedOption);
      };*/
      
      handleOption(e) {
        console.log("Selected!", e);
        this.setState({ selectedOption: e.target.value });
        console.log(this.state.selectedOption);
      }
      handleOption1(e) {
        console.log("Selected!", e);
        this.setState({ selectedOption1: e.target.value });
        console.log(this.state.selectedOption1);
      }

     

    submitForm = (e) => {
        console.log("e", this.state);
        e.preventDefault();
        console.log(this.state);
        let sign=JSON.parse(localStorage.getItem('data1'));
        console.log(sign.vid);
        let bodyFormData = new FormData()
        bodyFormData.append("file", this.state.file);
        bodyFormData.set("pname", this.state.title);
        bodyFormData.set("pdesc", this.state.describe);
        bodyFormData.set("pqty", this.state.qty);
        bodyFormData.set("pprice", this.state.price);
        bodyFormData.set("cat", this.state.selectedOption);
        bodyFormData.set("vdr", sign.vid);
        bodyFormData.set("papprove", "true");
        bodyFormData.set("prating", "1");
        // const config = {     
        //     headers: { 'content-type': 'multipart/form-data' },
            
        // }
       
    axios.post('http://localhost:8080/addProduct', bodyFormData,
    {headers: {
        
      'Content-Type':'multipart/form-data',
      'Access-Control-Allow-Origin': '*',
    }
  },)
      .then(res => {
        if (res.status === 200) {
        }
      } )
      window.location.href="/vendor";
    }
    componentDidMount() {
        fetch('http://localhost:8080/getallcategory')
            .then(response => {
                return response.json();
            }).then(data => {
                console.log(data);
                this.setState({
                    cat: data,
                });
                console.log(this.state.cid);
            });
    }
    render() {
        return (
            <div className='register'>
                <div className='register_container'>
                    <form >
                        {/*<div><select value={selectedOption} onChange={this.handleOption} options={optionItems}>{optionItems}</select></div>*/}
                        <select value={this.state.value1} onChange={this.handleOption}>{ this.state.cat.map((options) => (<option value1={options.cid}>{options.cid}</option>))}</select>
                        <select value={this.state.value2} onChange={this.handleOption1}>{ this.state.cat.map((options) => (<option value2={options.ctype}>{options.ctype}</option>))}</select>
                      

                        <h5>Product Title</h5><input type='text' name="title" value={this.state.title} onChange={this.handleChange} /><br />
                        <h5>Product Picture</h5><input className="photoID" type="file" onChange={this.onChangeHandler}/>
                        {/* <input type='file' name="file" value={this.state.file} onChange={this.onChangeHandler} /><br /> */}
                       
                        <h5>Description</h5><input type='text' name="describe" value={this.state.describe} onChange={this.handleChange} /><br />
                        
                        <h5>Quantity</h5><input type='number' name="qty" value={this.state.qty} onChange={this.handleChange} /><br />
                        <h5>Price</h5><input type='float' name="price" value={this.state.price} onChange={this.handleChange} /><br />
                        <Link to="vendor"> <button className='innerbutton' type="submit" value="Submit" onClick={this.submitForm} style={{backgroundColor:"black"}}>Add Product</button></Link><br />
                    </form>
                    <span>{this.state.error.titleerr}{this.state.error.describeerr}<br />
                        {this.state.error.imageerr}{this.state.error.priceerr}</span>
                </div>
            </div>

        )
    }
}