import { borderRadius } from '@mui/system';
import React from 'react';
import '../Product.css';
import {useStateValue} from './Stateprovider';
import Header from './Header.js';
// import food1 from "C:/Users/Admin/Downloads/Final_Project_Homemade_Creations/ReactJS/src/images/food1.jpeg";



function Product({id,title,describe,price,rating}) {
    const [{basket},dispatch]=useStateValue();
    var unique = new Date().valueOf();
    localStorage.setItem('uniqueid',+String(unique).substring(3, 13));
    let sign=JSON.parse(localStorage.getItem('data1'));
 
  

    const addToBasket=() =>{
        //dispatch item in data layer




        console.log(sign)
        if(sign !== null){


            dispatch({
                type: 'ADD_TO_BASKET',
                item:{
                    pid:id,
                   
                },
            });


            const requestBoday = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({  productId: id,
                    customeremail:sign.uemail})
               
            }
            console.log("body", sign);
            fetch('http://localhost:8080/addCart', requestBoday)
            .then(response => response.json())
            .then(data => console.log("data", data));
        } 
        else{
            window.location.href="/login";
        }
    
  
    };
    return (
        <div className='product'>
            <div className='product_info'>
                <div className='product_rating'>
                  Rating:  {Array(rating).fill().map((_,i)=>(<p>⭐⭐⭐</p>))}                    
                </div>
            </div>
            <button  onClick={addToBasket} style={{width:"150px", color:"black", backgroundColor:"Yellow",borderRadius:"10px" ,  fontSize: "1rem"}}>Add to Cart</button>
        </div>
    )



            



}

export default Product
