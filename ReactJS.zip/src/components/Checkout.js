import React, { Component } from 'react'
import '../Checkout.css';
import Placeorder from './Placeorder.js';
import Header from './Header.js';
import '../style.css';

// import {useHistory} from "react-router-dom";
class Checkout extends Component {
    
    constructor(props)
    {
        super(props);
        this.state={
            to: [],
            searcherror:" "
        }
        
    }


    
   



    componentDidMount = () => {
        fetch("http://localhost:8080/getAllCart")
            .then(resp => resp.json())
            .then(data => this.setState({ to: data }));
            

    }
    render() {
        console.log("data",this.state.to);
        
        var totalAmount = 0;
        var countcart = 0;
        let sign=JSON.parse(localStorage.getItem('data1'));
        this.state.to.map(element=>{
            if(element && element.totalprices && element.customeremail==sign.uemail){
                totalAmount += element.totalprices;
                countcart += element.productquantity;

                
            }
        });
        console.log("totalAmount", totalAmount);
        console.log("countcart",countcart);
        return (
<div>
{

   
    <div className='vhome'>
                    <div className='vhome_container'>
                  
                        <div className='vhome_row'>
                            <table>
                                <tr>
                                    {/* <th style={{backgroundColor:"black"}}>Product ID</th> */}
                                    <th style={{backgroundColor:"black"}}>Product Picture</th>
                                    <th style={{backgroundColor:"black"}}>Product Name</th>
                                    <th style={{backgroundColor:"black"}}>Product Price</th>
                                    <th style={{backgroundColor:"black"}}>Product Quantity(units)</th>
                                    <th style={{backgroundColor:"black"}}>Total Price</th>
                                    
                                </tr>
                                { 
                               
                                    this.state.to.map(
                                        (o) => {
                                           
                                            let sign=JSON.parse(localStorage.getItem('data1'));
                                            return (
                                                
                                           o.customeremail === sign.uemail ? (

                                            

                                                <tr>
                                                    {/* <td>{o.pid}</td> */}
                                                    <td><img src={'data:image/png;base64,'+o.productimage} style={{height:"100px",width:"100px",borderRadius:"2px" ,padding:"5px"}}></img></td>
                                                    <td>{o.productname}</td>
                                                    <td>{o.productprices}</td>
                                                    <td>{o.productquantity}</td>
                                                    <td>{o.totalprices}</td>
                                                    
                                                </tr>



                                            ): null
                                            );
                                        }
                                    )
                                }
                            </table>


                        <div class="card" style={{width: "15rem", height:"9rem"}}>
                         <div class="row">
                        
                         <div class="card-body">
                         <h5 class="card-title"> <b>Rs.{totalAmount}</b></h5>
                         <Placeorder></Placeorder>
                         
                         </div>
                         
                         </div>

                           
                        </div>
                        </div>
                        
                       
                    </div>
                    
                </div>
                 

}
<br></br>
</div>


        )
    }


    

}
export default Checkout
