import React from 'react';
import { Table, Button, Alert } from 'react-bootstrap';

class DeleteProduct extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        error: null,
        data: [],
        response: {}
      }
    }
  
    componentDidMount() {
      const apiUrl = 'http://localhost:8080/vdeleteproduct';
  
      fetch(apiUrl)
        .then(res => res.json())
        .then(
          (result) => {
            this.setState({
              data: result
            });
          },
          (error) => {
            this.setState({ error });
          }
        )
    }
  
    deleteProduct(productId) {
      const { data} = this.state;
  
      const apiUrl = 'http://localhost:8080/vdeleteproduct';
      const formData = new FormData();
      formData.append('productId', productId);
  
      const options = {
        method: 'POST',
        body: formData
      }
  
      fetch(apiUrl, options)
        .then(res => res.json())
        .then(
          (result) => {
            this.setState({
              response: result,
              data: data.filter(product => product.pid !== productId)
            });
          },
          (error) => {
            this.setState({ error });
          }
        )
    }
  
    render() {
      const { error, data} = this.state;
  
      if(error) {
        return (
          <div>Error: {error.message}</div>
        )
      } else {
        return(
          <div>
            <h2>Product List</h2>
            {this.state.response.message && <Alert variant="info">{this.state.response.message}</Alert>}
            <Table>
              <thead>
                <tr>
                  <th>productId</th>
                  <th>Product Name</th>
                  <th>prating</th>
                  <th>Price</th>
                  <th>pdesc</th>
                </tr>
              </thead>
              <tbody>
                {data.map(product => (
                  <tr key={product.pid}>
                    <td>{product.pid}</td>
                    <td>{product.pname}</td>
                    <td>{product.prating}</td>
                    <td>{product.pprice}</td>
                    <td>
                      <Button variant="info" onClick={() => this.props.editProduct(product.pid)}>Edit</Button>
                      &nbsp;<Button variant="danger" onClick={() => this.deleteProduct(product.pid)}>Delete</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        )
      }
    }
  }
  
  export default DeleteProduct;