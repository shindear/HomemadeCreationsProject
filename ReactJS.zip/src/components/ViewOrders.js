import React from 'react'
import '../compheader.css';

export default class ViewOrders extends React.Component{
    constructor(props)
    {
        super(props);
        this.state = {
            to: []
        }
    }
    componentDidMount =()=>{
        fetch("http://localhost:8080/getPlaceOrder")
        .then(resp => resp.json())
        .then(data =>{
            {this.setState({to: data})}}
            );
            console.log(this.state.to.length);    
    }
    render()
    {
        const to1= this.state.to.length;
    return (
        <div>
           {to1!=0
           ? <div className='vhome'>
                <div className='vhome_container'>
                         <div className='vhome_row'>

                                <table>
                                    <tr>
                                        
                                <th style={{backgroundColor:"black"}}>Order Date</th>
                                <th style={{backgroundColor:"black"}}>Customer Name</th>
                                <th style={{backgroundColor:"black"}}>Email</th>
                                <th style={{backgroundColor:"black"}}>Contact Number</th>
                                <th style={{backgroundColor:"black"}}> Address</th>
                                <th style={{backgroundColor:"black"}}>Order TotalPrice</th>
                                <th style={{backgroundColor:"black"}}>Order Status</th>
                                </tr>
                                     { this.state.to.map((o) => {
                                         return(
                                         <tr>
                                         <td>{o.orderdate}</td>
                                         <td>{o.cname}</td>
                                         <td>{o.custemail}</td>
                                         <td>{o.contactno}</td>
                                         <td>{o.address}</td>
                                         <td>{o.totalprice}</td>
                                         <td>{o.status}</td>
                                         </tr>
                                         );})}
                            </table>
                        </div>
                    <div className='vhome_row'>Total Number Of Orders:<br/>{this.state.to.length}</div>
                </div>
            </div>
        : < div style={{textAlign:"center",color:"black"}}><h2>No Data</h2></div> 
      }
      </div>
    );
    }
}