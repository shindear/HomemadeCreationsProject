import React from "react";
import { Card, Col, Row } from "react-bootstrap";
import '../style.css';
import Photo2 from '../Photo2.jpg';
import Product from './Product.js';



class HomedecorCategory extends React.Component{
    constructor(props)
    {
        super(props);
        this.state={
            sr: [],
            searcherror:" "
        }
    }
    componentDidMount =()=>{
        fetch("http://localhost:8080/homedecor")
        .then(resp => resp.json())
        .then(data => 
            {if(data.length!=0)
                {
                    console.log(JSON.stringify(data));
                    this.setState({sr: data})
                }
                // else
                // {
                //     this.setState({searcherror: "Result not found :("});
                // }
            });
    }

    render() {
      return (
          <div class="container-fluid mt">
               <div class="row">
            { this.state.sr.map((o) =>
                          
                         
                             
                          <div class="col-3">
                           
                           <div class="card" style={{width: "15rem"}}>
                           <div class="row">
                           <div class="col-9">
                              <img src={'data:image/png;base64,'+o.productimage}  style={{height:"150px",width:"150px"}}/>
                             </div>
                              <div class="col-3">
                             <img src='https://miro.medium.com/max/1024/1*nZ9VwHTLxAfNCuCjYAkajg.png' height="20px" width="20px"/>
                               </div>
             </div>
               <div class="card-body">
               <h5 class="card-title" style={{fontSize:"1.2rem"}}>{o.pname} <b style={{float:"right"}}>Rs.{o.pprice}</b></h5>
                     {/* <h5 class="card-title">{o.pprice}</h5> */}
               <p class="card-text">{o.pdesc}</p>
               <Product id={o.pid} title={o.pname} price={o.pprice} describe={o.pdesc}  rating={o.prating}></Product>
              </div>
                   </div>
                          
                          </div>
                       
                     
                        )}
                    </div>
                    <br></br>
      </div>
      )
  }
  
  }
export default HomedecorCategory;