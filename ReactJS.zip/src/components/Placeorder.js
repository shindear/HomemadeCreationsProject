import { borderRadius } from '@mui/system';
import React from 'react';
import '../Checkout.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Placeorder({custid}) {

    const  orderPlaced=() =>{
        let signs=JSON.parse(localStorage.getItem('data1'));
        const requestBoday = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({custid: signs.uid})
           
        }
        console.log("body", requestBoday);
        fetch('http://localhost:8080/placeOrder', requestBoday)
        .then(response => response.json())
        .then(data => notify());
        
          window.location.href="/";
        };
        const notify = () => toast.success('Your Order Placed Successfully !', {
            position: "top-right",
            autoClose: 7000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
        return (
            <div className='product'>
                
                <button  onClick={orderPlaced} style={{width:"150px", color:"black", backgroundColor:"Yellow",borderRadius:"10px" ,  fontSize: "1rem"}}>Add to Cart</button>
{/* Same as */}
<ToastContainer />
            </div>

        )

}

export default Placeorder