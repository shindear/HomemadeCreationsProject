import React ,{useState} from 'react';
import '../Header.css';
import SearchIcon from '@material-ui/icons/Search';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import HomeIcon from '@material-ui/icons/Home';
import {Link} from 'react-router-dom';
import food1 from "../images/food1.jpeg";
import {useStateValue} from './Stateprovider';
function Header() {
  
    
    
   
    const [{basket}]=useStateValue();
    const [text,setText]=useState("");
    let textInput=React.createRef();
    localStorage.setItem('text',text);
    //console.log(JSON.parse(localStorage.getItem('data1')));
    let sign=JSON.parse(localStorage.getItem('data1'));
    let signOut= ()=>{
        if(sign!=null)
        {
            localStorage.removeItem('uniqueid');
            localStorage.removeItem('data1');
            window.location.href = '/login';
        }
    }
    console.log(sign);
    return (
        
        <div className='header'>
            <Link to="/">
              <HomeIcon className='header_homeIcon'/> 
             
            </Link>
            <img src={'/img.jpeg'} style={{width:"150px"}}/>&emsp;&emsp;
            
            <Link to="/food" style={{textDecoration:"none"}}>
              <p className='header_category' >Food</p>
              
            </Link>
            <Link to="/homedecor" style={{textDecoration:"none"}}>
              <p className='header_category'>Homedecor</p>
            </Link>
            <Link to="/jewellary" style={{textDecoration:"none"}}>
              <p className='header_category'>Jewellery</p>
            </Link>
            <Link to="/cloths" style={{textDecoration:"none"}}>
              <p className='header_category'>Cloths</p>
            </Link>
            <div className='header_search'>
                <input  className='header_searchInput' ref={textInput} type="text" placeholder='search here'/>&emsp;
                <Link to="/search" style={{textDecoration:"none"}}><SearchIcon className='header_searchIcon' onClick={()=>(setText(textInput.current.value))}/></Link>
            </div >
            <div className='header_nav'>
                <Link to={!sign && "/login"} style={{textDecoration:"none"}}>
                    <div className='header_option'>
                     <span className='header_optionLineOne'>Hello {!sign ?'User':sign.ufname}</span>
                     <span className='header_optionLineTwo' onClick={signOut}>{sign? 'Sign Out':'Sign In'}</span>
                    </div>
                </Link> 
                {/* <Link to={"/order"}> */}
                {/* <div className='header_option'>
                    <span className='header_optionLineOne'>Returns</span>
                    <span className='header_optionLineTwo'>& Order</span>
                </div> */}
                {/* </Link> */}
                <Link to="/wallet" style={{textDecoration:"none"}}>
                    <p className='header_category'>Wallet</p>
                </Link>
                <Link to="/checkout" style={{textDecoration:"none"}}>
                    <div className='header_optionBasket'>
                        <ShoppingCartIcon />
                        <span className='header_optionLineTwo header_basketCount'>{basket?.length}</span>                
                    </div>
                </Link> 
            </div>
               
        </div>
    )
}

export default Header
